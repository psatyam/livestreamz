    <footer>
        <div class="container">
            <div class="row footer_top">
                <img src="images/header/logo_bottom.png" alt="#">
            </div>
            <div class="row footer_bottom">
                <div class="left">
                    Copyright &copy; 2016 <span></span>  |  All Right Reserved
                </div>
                <!-- Menu -->
                <div class="footer_menu">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index-2.html">Home</a></li>
                        <li><a href="about.html">About</a></li>
                        <li><a href="schedule.html">Schedule</a></li>
                        <li><a href="blog.html">Blog</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer> 
   
    <!-- jQuery -->
<!--    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-1.12.3.min.js"></script>-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/vendors/flexslider/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.countdown.min.js"></script>
<!--    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap-datetimepicker.js"></script>-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap-switch.min.js"></script>
<!--    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>-->
    <script src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script> 
    
    <!-- LightBox -->
    <script src="<?php echo base_url();?>assets/vendors/Lightbox/lightbox.min.js"></script>
    <!-- Mixitup JS -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/vendors/mixitup/jquery.mixitup.min.js"></script>  
    
    <!-- Map JS -->
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/vendors/map/gmaps.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendors/map/map.js"></script>
     
    <script src="<?php echo base_url();?>assets/js/custome.js"></script> 
</body>

</html>